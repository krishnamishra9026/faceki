<?php

return [
    'company' => 'Company',
    'last_activity' => 'Last activity',
    'companies' => 'Companies',
    'created' => 'Created',
    'status' => 'status',
];