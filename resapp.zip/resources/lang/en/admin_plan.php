<?php

return [
    'plan' => 'Plan',
    'plan_name' => 'Plan name',
    'create_plan' => 'Create a Plan',
    'notice' => 'Plan will automaticaly create on the fly to the stripe dashboard',
    'Plan name' => 'Plan name',
    'enter_plan_name' => 'Enter plan name',
    'price' => 'Plan Price',
    'enter_price' => 'Enter plan price',
    'trial' => 'Plan Trial',
    'enter_trial' => 'Enter plan trial',
    'interval' => 'Plan interval',
    'select_interval' => 'Select interval',
    'daily' => 'Daily',
    'weekly' => 'Weekly',
    'monthly' => 'Monthly',
    'yearly' => 'Yearly',
    'team_plan' => 'Teams plan',
    'interval' => 'Interval',

    'team_notice' => 'Number of member allow for this Plan',
    'type' => 'plan type',
    'team_limit' => 'Team limit',
    'active' => 'Active',
    'inactive' => 'Inactive',
    'normal_plan' => 'Normal plan',
    'team_plan' => 'Team plan',
    'update_plan' => 'Update Plan',
    'create_company' => 'Create new company'

];