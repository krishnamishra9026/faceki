<?php

return [
    'stop_impersonation' => 'Stop impersonation',
    'my_dashboard' => 'My dashboard',
    'admin_panel' => 'Admin panel',
    'my_Account' => 'My account',
    'developer_panel' => 'Developer panel',
    'logout' => 'Logout',

];