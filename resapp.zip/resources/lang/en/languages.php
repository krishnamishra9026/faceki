<?php

return [
    'english'       => 'English',
    'nederlands'    => 'Nederlands',
    'french'        => 'French',
    'spanish'       => 'Spanish'
];