<?php

return [
    'new' => 'Create New Ticket',
    'title' => 'Title',
    'ticket' => 'Ticket',
    'tickets' => 'Tickets',
    'no_current_ticket' => 'There are currently no tickets.',
    'category' => 'Category',
    'select_category' => 'Select Category',
    'priority' => 'Priority',
    'select_priority' => 'Select Priority',
    'low' => 'Low',
    'medium' => 'Medium',
    'hight' => 'High',
    'message' => 'Message',
    'open' => 'Open Ticket',
    'add_reply' => 'Add reply',
    'submit' => 'Submit',
    'my_tickets' => 'My Tickets',
    'no_tickets' => 'You have not created any tickets.',
    'last_updated' => 'Last Updated',
    'status' => 'Status',
    'category_select' => 'Select category'
];