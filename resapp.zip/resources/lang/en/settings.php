<?php

return [
    'settings' => 'Settings',
    'color_scheme' => 'Please choose a color scheme',
    'site_url' => 'Site URL',
    'login' => 'Login',
];
