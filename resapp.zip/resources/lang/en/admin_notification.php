<?php

return [
    'notification' => 'Notification',
    'new' => 'New annoucement',
    'subject' => 'Subject',
    'enter_subject' => 'Enter subject',
    'enter_message' => 'Enter message',
    'message' => 'Message',
    'action' => 'Action Text',
    'url' => 'URL',
    'enter_url' => 'Enter link when click to url text',
    'footer' => 'Message footer ',
    'enter_thank' => 'Enter Thanks message',
    'send' => 'Send notification to all user',
    'click' => 'Exp: Click here !'

];