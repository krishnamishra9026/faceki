<?php

return array (
  'english' => 'Engels',
  'french' => 'Frans',
  'nederlands' => 'Nederlands',
  'spanish' => 'Spaans',
);
