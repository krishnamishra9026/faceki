<?php

return array (
  '2fa_title' => 'Two Factor Authentication',
  '2fa_token' => 'Verificatietoken',
  'failed' => 'Deze gegevens komen niet overeen met onze gegevens.',
  'login' => 'Log in',
  'pass_forget' => 'Uw wachtwoord verge',
  'register_account' => 'Registreer Nieuw Account',
  'remember' => 'Onthoud me',
  'resend_activation' => 'Activerings-e-mail opnieuw verzenden',
  'resend_token' => 'Activeringstoken opnieuw verzenden',
  'reset_password' => 'Reset wachtwoord',
  'send_reset_pass_link' => 'Verzend Wachtwoord Reset Link',
  'signup' => 'Aanmelden',
  'throttle' => 'Te veel inlogpogingen. Probeer het opnieuw over:seconds seconden.',
);
