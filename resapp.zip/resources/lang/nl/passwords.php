<?php

return array (
  'password' => 'Wachtwoorden moeten minimaal zes tekens bevatten en overeenkomen met de bevestiging.',
  'reset' => 'Je wachtwoord is gereset!',
  'sent' => 'We hebben uw wachtwoordresetlink gemaild!',
  'token' => 'Dit token voor het opnieuw instellen van het wachtwoord is ongeldig.',
  'user' => 'We kunnen geen gebruiker vinden met dat e-mailadres.',
);
