<?php

return array (
  'action' => 'Actietekst',
  'click' => 'Exp: klik hier!',
  'enter_message' => 'Voer bericht in',
  'enter_subject' => 'Voer onderwerp in',
  'enter_thank' => 'Enter Bedankt bericht',
  'enter_url' => 'Voer link in wanneer klik om tekst te urleren',
  'footer' => 'Voettekst bericht',
  'message' => 'Bericht',
  'new' => 'Nieuwe aankondiging',
  'notification' => 'Kennisgeving',
  'send' => 'Stuur een melding naar alle gebruikers',
  'subject' => 'Onderwerpen',
  'url' => 'URL',
);
