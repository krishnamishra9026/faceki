<?php

return array (
  'admin_panel' => 'Administratie Paneel',
  'developer_panel' => 'Ontwikkelaarspaneel',
  'logout' => 'Uitloggen',
  'my_Account' => 'Mijn rekening',
  'my_dashboard' => 'Mijn dashboard',
  'stop_impersonation' => 'Stop imitatie',
);
