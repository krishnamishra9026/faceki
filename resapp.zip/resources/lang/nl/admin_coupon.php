<?php

return array (
  'code' => 'Coupon code',
  'coupon' => 'Coupon',
  'coupon_name' => 'Coupon naam',
  'create_coupon' => 'Maak een kortingsbon / korting',
  'duration' => 'Looptijd',
  'duration_month' => 'Duur in maanden',
  'duration_notice' => 'Alleen vereist als de duur wordt herhaald, in welk geval het een positief geheel getal moet zijn dat het aantal maanden aangeeft dat de korting van kracht is.',
  'enter_coupon_name' => 'Voer de plannaam in',
  'enter_price' => 'Voer couponprijs in',
  'forever' => 'Voor altijd',
  'notice' => 'Coupon wordt automatisch gemaakt op de streep naar het streepdashboard',
  'once' => 'Een keer',
  'percentage_off' => 'Percentage uit',
  'price' => 'Coupon prijs',
  'repeating' => 'Het herhalen',
  'select_duration' => 'Selecteer duur',
  'update_coupon' => 'Coupon bijwerken',
);
