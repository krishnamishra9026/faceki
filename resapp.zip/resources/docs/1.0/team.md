# Teams

---

- [Manage team](#section-1)
- [Manage team](#section-2)

SaaS Web includes support for allowing your users to create and join teams when he subscribes on a apropriate plan. Teams provide a great way for users to share access to resources with other users of your application.

> {warning} To see this menu, user should subscribe on a team plan or added as a team member.

<a name="section-1"></a>
  It ain't fun to work alone. SaasWeb make Collaborations super easy.
When subscribed on a team plan, user will see the manage team menu, on this page user will have possibility to add new team member.
 <img src="{{ asset('img/screens/team.png') }}">
<br>
<a name="section-2"></a>
In this page user will see all team member.
<img src="{{ asset('img/screens/my_team.png') }}">
