# Release notes

---
This script will be updated regularily with latest version of framework & plugins. Please share your feedback, feature request which will be surely implemented in upcoming versions.

- [Version 1.0](#section-1)

<br><br>
<a name="section-1"></a>

#### August 07, 2019
First version released.