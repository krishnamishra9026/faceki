@extends('admin.layouts.default')

@section('admin.breadcrumb')
<li class='breadcrumb-item active'>Tickets</li>
@endsection

@section('admin.content')
<div class="clearfix">

</div>
@endsection