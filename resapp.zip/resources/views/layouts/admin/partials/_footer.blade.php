<footer class="app-footer">
    <span><a href="{{ route('home') }}">{{ config('app.name') }}</span>
</footer>
