@component('mail::message')
# Password Updated

We are just letting you know your password was updated.

Thanks,<br>
{{ config('app.name') }}
@endcomponent
