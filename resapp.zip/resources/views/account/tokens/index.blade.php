@extends('account.layouts.default')

@section('content')
    <passport-personal-access-tokens></passport-personal-access-tokens>
@endsection